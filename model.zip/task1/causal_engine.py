def extract_causal_evidence(transcript, event):
    evidence = []
    factors = []

    for turn in transcript["turns"]:
        if "not allow" in turn["text"].lower():
            evidence.append(turn)
            factors.append("Policy denial")

    return {
        "call_id": transcript["call_id"],
        "event": event,
        "factors": list(set(factors)),
        "evidence": evidence
    }