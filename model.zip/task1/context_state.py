class ContextState:
    def _init_(self):
        self.call_ids = []
        self.event = None
        self.evidence_turns = []
        self.causal_factors = []
        self.last_query = None