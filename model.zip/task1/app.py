import json
from causal_engine import extract_causal_evidence
from context_state import ContextState
from query_handler import handle_query

context = ContextState()

with open("transcripts.json") as f:
    transcripts = json.load(f)

event = "Escalation"

analysis = extract_causal_evidence(transcripts[0], event)

q1 = "Why did the call escalate?"
r1 = handle_query(q1, context, analysis)

q2 = "Which agent turn caused it?"
r2 = handle_query(q2, context, analysis)

print("Q1:", r1)
print("Q2:", r2)